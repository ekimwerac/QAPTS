import  { DataResource} from '../services/DataResource';



export const Bootcamp = new DataResource('http://localhost:3000/bootcamps')

