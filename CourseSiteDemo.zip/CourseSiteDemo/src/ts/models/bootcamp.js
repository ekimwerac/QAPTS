"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bootcamp = void 0;
var DataResource_1 = require("../services/DataResource");
exports.Bootcamp = new DataResource_1.DataResource('http://localhost:3000/bootcamps');
