var world = "World";
console.log("Hello ".concat(world));
